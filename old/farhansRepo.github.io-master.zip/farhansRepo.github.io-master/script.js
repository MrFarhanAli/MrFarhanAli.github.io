// Footer Content 
document.getElementById("footdate").innerHTML = new Date().getFullYear();
